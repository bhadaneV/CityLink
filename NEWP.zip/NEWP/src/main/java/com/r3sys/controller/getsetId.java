package com.r3sys.controller;

public class getsetId {
	
	
	
	public static String citizenContactId;

	public static String getCitizenContactId() {
		return citizenContactId;
	}

	public static void setCitizenContactId(String citizenContactId) {
		getsetId.citizenContactId = citizenContactId;
	}
	
	
	

}
